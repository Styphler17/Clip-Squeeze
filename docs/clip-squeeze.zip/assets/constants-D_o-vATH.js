import{Z as o}from"./zap-Cwfbc4Dw.js";import{C as i}from"./clock-CIrfGpXT.js";import{e}from"./index-DM4jLR1H.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=e("Award",[["path",{d:"m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526",key:"1yiouv"}],["circle",{cx:"12",cy:"8",r:"6",key:"1vp47v"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const t=e("Eye",[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=e("Gem",[["path",{d:"M6 3h12l4 6-10 13L2 9Z",key:"1pcd5k"}],["path",{d:"M11 3 8 9l4 13 4-13-3-6",key:"1fcu3u"}],["path",{d:"M2 9h20",key:"16fsjt"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=e("Wrench",[["path",{d:"M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z",key:"cbrjhi"}]]),l=[{id:"aggressive",name:"Aggressive",description:"Maximum compression, good for sharing",icon:o,crf:35,preset:"fast",scale:80,estimatedReduction:"70-85%",color:"text-red-500"},{id:"fast",name:"Fast",description:"Quick processing with decent compression",icon:i,crf:30,preset:"veryfast",scale:90,estimatedReduction:"50-65%",color:"text-orange-500"},{id:"balanced",name:"Balanced",description:"Best balance of size and quality",icon:s,crf:25,preset:"medium",scale:100,estimatedReduction:"60-75%",color:"text-blue-500"},{id:"high-quality",name:"High Quality",description:"Minimal quality loss, moderate compression",icon:c,crf:20,preset:"slow",scale:100,estimatedReduction:"40-55%",color:"text-green-500"},{id:"lossless",name:"Lossless",description:"No quality loss, minimal compression",icon:t,crf:15,preset:"veryslow",scale:100,estimatedReduction:"10-25%",color:"text-purple-500"},{id:"custom",name:"Custom",description:"Full control over compression settings",icon:a,crf:25,preset:"medium",scale:100,estimatedReduction:"Variable",color:"text-gray-500"}],m=["video/mp4","video/avi","video/quicktime","video/x-msvideo","video/x-ms-wmv","video/x-flv","video/webm","video/3gpp","video/ogg","video/x-matroska"];export{l as C,t as E,m as S,a as W};
